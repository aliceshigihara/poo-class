package com.mycompany.impressora;

public class Mensagem implements Imprimivel {
    private String mensagem;

    public Mensagem(String mensagem) {
        this.mensagem = mensagem;
    }
    
    @Override
    public String retornarTexto() {
        return mensagem;
    }
}