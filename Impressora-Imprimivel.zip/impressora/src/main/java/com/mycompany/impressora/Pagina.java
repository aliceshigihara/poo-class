package com.mycompany.impressora;
import java.util.List;

public class Pagina {
    private List<String> paragrafos;

    public Pagina(List<String> paragrafos) {
        this.paragrafos = paragrafos;
    }

    public String retornarTexto() {
        StringBuilder sb = new StringBuilder();
        for (String p : paragrafos) {
            sb.append(p).append("\n");
        }
        return sb.toString();
    }
}