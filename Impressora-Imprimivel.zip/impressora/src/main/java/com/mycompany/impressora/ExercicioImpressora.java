package com.mycompany.impressora;

import java.util.Arrays;
import java.util.List;

public class ExercicioImpressora {

    public static void main(String[] args) {
        
        Impressora impressora = new Impressora();

        Mensagem msg = new Mensagem("Oi, este é uma mensagem para o professor Pizzini! Boa noite, Pizzini.");
        impressora.imprimir(msg);

        Pagina p1 = new Pagina(Arrays.asList(
            "Era uma vez, em uma aula de POO",
            "Todos os alunos estudaram herança naquele dia.",
            "Outro dia, houve aula sobre interfaces."
        ));

        Pagina p2 = new Pagina(Arrays.asList(
            "Um dia, um aluno faltou e acabou perdendo a aula de agregação",
            "Mas os seus colegas o ajudaram, e passaram todo o conteúdo"
        ));

        Livro livro = new Livro(List.of(p1, p2));
        impressora.imprimir(livro);
    }
}
