package com.mycompany.impressora;


public class Impressora {

    public void imprimir(Imprimivel conteudo) {
        System.out.println(conteudo.retornarTexto());
    }
}
