package com.mycompany.impressora;

public interface Imprimivel {
    String retornarTexto();
}
