package com.mycompany.impressora;

import java.util.List;

public class Livro implements Imprimivel {

    private List<Pagina> paginas;

    public Livro(List<Pagina> paginas) {
        this.paginas = paginas;
    }

    @Override
    public String retornarTexto() {
        StringBuilder sb = new StringBuilder();
        int numeroPaginas = 0;

        for (Pagina paginas : paginas) {
            sb.append("Página ").append(numeroPaginas++).append(":\n");
            sb.append(paginas.retornarTexto()).append("\n");

        }

        return sb.toString();
    }
}
